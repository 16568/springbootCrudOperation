package com.example.firstmaven.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.firstmaven.model.Student;

@Repository
public class StudentDao 
{

	public static ArrayList<Student> studentlist= new  ArrayList<>();
	
	public Student addStudent(Student student)
	{
		studentlist.add(student);
		return student;
	}
	
	public List<Student> getAllStudentdetails()
	{
	 return studentlist;
	}
	
	
}
