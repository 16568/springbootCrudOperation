package com.example.firstmaven.model;

public class Student {
	
	Integer id;
	String sname;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public Student (Integer id, String sname) {
		super();
		this.id = id;
		this.sname = sname;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Student()
	 {
		 
	 }
	
	
}
