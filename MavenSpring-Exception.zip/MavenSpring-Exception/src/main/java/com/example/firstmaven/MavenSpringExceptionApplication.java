package com.example.firstmaven;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenSpringExceptionApplication{

	public static void main(String[] args) {
		SpringApplication.run(MavenSpringExceptionApplication.class, args);
		//UserRepository UserRespository = context.getbean(UserRepository.)
		
		//User user = new User();
		
		
	}

}
