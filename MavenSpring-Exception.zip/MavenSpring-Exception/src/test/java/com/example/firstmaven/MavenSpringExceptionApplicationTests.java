package com.example.firstmaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenSpringExceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
