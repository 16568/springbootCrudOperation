package com.example.firstmaven.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.firstmaven.model.Student;
import com.example.firstmaven.service.StudentService;

@RestController
public class ProductController {
	
	@Autowired
	StudentService studentservice;
	
	@RequestMapping("/StudentDetails")
	public String getStudentdetails()
	{
		return "Student details created successfully";
	}
	
	@GetMapping("/StudentdetailsTst")
	public String getStudentdetailsTst()
	{
		return "Student test details created successfully";
	}
	
	@GetMapping("/getAllStudentdetails")
	public List<Student> getAllStudentdetails()
	{
		return studentservice.getAllStudentdetails();
	}
	
	@PostMapping("/AddStudentDetails")
	public Student AddStudentdetails(@RequestBody Student student)
	{
		//Student s1= new Student();--//object creation
		//s1.setId(student.getId()+100);--//id generate +100
		//s1.setSname(student.getSname().toUpperCase());//name in uppercase
		//return s1;
		//return student;
		//return "adding Student details  successfully";
		
		Student student1 = studentservice.addStudent(student);
		return student1;//responseentity==200ok
	}

	@DeleteMapping("/DeleteStudentDetails/{id}")
	public String AddStudentdetails( @PathVariable("id") String id)
	{
		return "Delete Student details created successfully";
	}
	
	@PutMapping("/UpdateStudentDetails/{id}")
	public String UpdateStudentdetails( @PathVariable("id") String id)
	{
		return "Update Student details created successfully "+id;
	}
	
}
